package org.babu.springse;

/*import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;*/

//import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;


public class Circle implements Shape{
	
	private Point center;
	

	public Point getCenter() {
		return center;
	}
	
	@Autowired
	public void setCenter(Point center) {
		this.center = center;
	}
	
/*	@Resource(name="center")//giving exception 
	public void setCenter(Point center) {
		this.center = center;
	}*/

/*	@Resource //without name element it  will find  in the spring.xml find for a bean name "center" giving exception 
	public void setCenter(Point center) {
		this.center = center;
	}*/
	
	
/*	@PostConstruct //not working
	public void initializeCircle(){

		System.out.println("Init of Circle");
	}
	
	@PreDestroy//not working
	public void destroyCircle(){

		System.out.println("Destroy of circle");
	}
*/


	
	@Override
	public void drow() {
		// TODO Auto-generated method stub
		System.out.println("Drowing Cirle");
		System.out.println("Circle: Point is :(" +center.getX() + "," + center.getY()+ ")");
	}
	

}

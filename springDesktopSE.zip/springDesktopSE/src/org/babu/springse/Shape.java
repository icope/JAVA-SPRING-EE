package org.babu.springse;

public interface Shape {
	
	public void drow();

}

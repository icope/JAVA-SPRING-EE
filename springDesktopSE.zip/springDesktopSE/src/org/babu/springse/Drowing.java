package org.babu.springse;
//import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Drowing {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Triangle triangle = new Triangle();*/
/*		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Triangle triangle = (Triangle) context.getBean("triangle");
		triangle.drow();
		((ClassPathXmlApplicationContext) context).close();*/
		
		//Since the app context is a ResourceLoader (i.e. I/O operations) it consumes resources that need to 
		//be freed at some point. It is also an extension of AbstractApplicationContext which implements Closable. 
		//Thus, it's got a close() method and can be used in a try() for jdk-7 and above don't need finally() along with try()
		
		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml")) {
			 
			//Creating object of Triangle
			
			/*	 Triangle triangle = (Triangle) context.getBean("triangle"); // here triangle is the page name reference
			  triangle.drow();
			  
			 // Creating object of Circle
			  
			  Circle circle = (Circle) context.getBean("circle");
			  circle.drow();*/
			  
			 //The most efficient way to code is code to inter face not to class directly
			  
			  Shape shape =(Shape) context.getBean("circle");     // here if we put circle it will load object from Circle class
			 // Shape shape =(Shape) context.getBean("triangle"); //if we put triange it will load object from Triangle class
			  shape.drow();
			  //System.out.println(context.getMessage("hello", null, "Default Greeting", null)); //Not working 
			  
			}//for Jdk 7 and letter here we dont need catch pair with try.

		

		//Not good Approach and it's not serve it's purpose (PostConstruct and preDestroy not working)
/*
			@SuppressWarnings("resource")
			AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
			context.registerShutdownHook();
			Shape shape =(Shape) context.getBean("circle"); 
			shape.drow();
*/
		
/*		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		 Triangle triangle = (Triangle) context.getBean("triangle"); // here triangle is the page name reference
		  triangle.drow();
		  
		 // Creating object of Circle
		  
		  Circle circle = (Circle) context.getBean("circle");
		  circle.drow();*/
		

	
	}
	
}

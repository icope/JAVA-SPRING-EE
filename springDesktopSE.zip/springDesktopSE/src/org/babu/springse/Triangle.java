package org.babu.springse;


/*import java.util.List;*/

public class Triangle implements Shape {

/*	private List<Point> points;

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}
	
	public void drow(){	
		
		for(Point point : points){
			
			System.out.println("Point ("+ point.getX() +"," +point.getY() +")");
		}
	}
*/
//checking Inheritance in spring.xml page  using List 

	
	private Point pointA;
	private Point pointB;
	private Point pointC;

	


	public Point getPointA() {
		return pointA;
	}
	
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}	
	
	public Point getPointB() {
		return pointB;
	}
	
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}
	
	public Point getPointC() {
		return pointC;
	}	
	public void setPointC(Point pointC) {
		this.pointC = pointC;
	}



	public void drow(){	
		System.out.println("Drowing Triangle...");
		System.out.println("PointA("+ getPointA().getX() +"," +getPointA().getY() +")");
		System.out.println("PointB("+ getPointB().getX() +"," +getPointB().getY() +")");
		System.out.println("PointC("+ getPointC().getX() +"," +getPointC().getY() +")");
		
	}
	

/*	private String type;
	private int height;
	
	public int getHeight() {
		return height;
	}

	public Triangle(String type){

		this.type = type;

	}

	public Triangle(int height){

		this.height = height;

	}

	public Triangle(String type, int height){

		this.height=height;
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public void drow(){	
		System.out.println("PointA("+ getPointA()+")");

	}
	*/

}
